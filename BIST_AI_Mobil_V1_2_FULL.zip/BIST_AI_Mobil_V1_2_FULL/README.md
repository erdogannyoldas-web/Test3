# BIST AI Mobil V1.2

Telefon öncelikli BIST tarama ve geçmiş veri replay prototipi.

## V1 özellikleri
- Dakika bazlı mock replay
- Sinyal puanlama ve aday sıralama
- Risk/ödül görünümü
- Sinyal geçmişi
- Performans istatistikleri

> Bu sürüm gerçek zamanlı veri veya otomatik emir içermez. Yatırım tavsiyesi değildir.

## APK üretimi
GitHub Actions içindeki `Android APK` iş akışını çalıştırın. İşlem tamamlandığında `BIST-Sinyal-V1-APK` artifact'ini indirin.
