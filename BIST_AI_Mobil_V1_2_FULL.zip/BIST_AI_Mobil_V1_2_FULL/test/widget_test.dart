import 'package:bist_ai_mobil_v1/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Ana ekran açılır', (tester) async {
    await tester.pumpWidget(const BistScannerApp());
    expect(find.text('BIST Sinyal V1'), findsOneWidget);
    expect(find.text('En güçlü adaylar'), findsOneWidget);
  });
}
