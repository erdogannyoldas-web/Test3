package com.doganiletisim.bist_ai_mobil_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
