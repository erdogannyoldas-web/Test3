import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const BistScannerApp());
}

class BistScannerApp extends StatelessWidget {
  const BistScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BIST Sinyal V1',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2DD4BF),
        scaffoldBackgroundColor: const Color(0xFF07111F),
        cardTheme: const CardThemeData(
          color: Color(0xFF111D30),
          margin: EdgeInsets.zero,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final MockMarketRepository _repository = MockMarketRepository();
  final List<SignalEvent> _history = <SignalEvent>[];
  final Set<String> _capturedSignalKeys = <String>{};
  Timer? _timer;
  int _minuteIndex = 0;
  int _tabIndex = 0;
  bool _isPlaying = false;
  double _speed = 1;
  List<SignalResult> _results = <SignalResult>[];

  @override
  void initState() {
    super.initState();
    _recalculate(captureSignals: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _recalculate({required bool captureSignals}) {
    final snapshot = _repository.snapshotAt(_minuteIndex);
    final results = snapshot.map(ScoringEngine.score).toList()
      ..sort((a, b) => b.finalScore.compareTo(a.finalScore));

    if (captureSignals) {
      for (final result in results.where((item) => item.signal != SignalType.reject)) {
        final key = '${result.symbol}-$_minuteIndex';
        if (_capturedSignalKeys.add(key)) {
          _history.add(
            SignalEvent(
              symbol: result.symbol,
              minuteIndex: _minuteIndex,
              time: _clockFor(_minuteIndex),
              entryPrice: result.price,
              score: result.finalScore,
              riskReward: result.riskReward,
              signal: result.signal,
            ),
          );
        }
      }
      _updateHistoryOutcomes();
    }

    setState(() => _results = results);
  }

  void _updateHistoryOutcomes() {
    for (final event in _history) {
      final latest = _repository.pointFor(event.symbol, _minuteIndex);
      if (latest == null) continue;
      final change = ((latest.price - event.entryPrice) / event.entryPrice) * 100;
      event.currentChangePercent = change;
      event.maxGainPercent = max(event.maxGainPercent, change);
      event.maxDrawdownPercent = min(event.maxDrawdownPercent, change);
    }
  }

  void _togglePlay() {
    if (_isPlaying) {
      _timer?.cancel();
      setState(() => _isPlaying = false);
      return;
    }

    setState(() => _isPlaying = true);
    _timer = Timer.periodic(
      Duration(milliseconds: max(120, (1000 / _speed).round())),
      (_) {
        if (_minuteIndex >= MockMarketRepository.totalMinutes - 1) {
          _timer?.cancel();
          setState(() => _isPlaying = false);
          return;
        }
        _minuteIndex++;
        _recalculate(captureSignals: true);
      },
    );
  }

  void _reset() {
    _timer?.cancel();
    _history.clear();
    _capturedSignalKeys.clear();
    setState(() {
      _isPlaying = false;
      _minuteIndex = 0;
    });
    _recalculate(captureSignals: true);
  }

  String _clockFor(int minute) {
    final start = DateTime(2026, 7, 22, 10);
    final value = start.add(Duration(minutes: minute));
    return '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      ReplayPage(
        clock: _clockFor(_minuteIndex),
        minuteIndex: _minuteIndex,
        speed: _speed,
        isPlaying: _isPlaying,
        results: _results,
        onPlay: _togglePlay,
        onSpeedChanged: (value) {
          _timer?.cancel();
          setState(() {
            _speed = value;
            _isPlaying = false;
          });
        },
        onSliderChanged: (value) {
          _timer?.cancel();
          setState(() {
            _isPlaying = false;
            _minuteIndex = value.round();
          });
          _recalculate(captureSignals: true);
        },
      ),
      HistoryPage(history: _history.reversed.toList()),
      PerformancePage(history: _history),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('BIST Sinyal V1'),
            Text('Replay test sürümü', style: TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _reset,
            tooltip: 'Testi sıfırla',
            icon: const Icon(Icons.restart_alt),
          ),
        ],
      ),
      body: SafeArea(child: pages[_tabIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (value) => setState(() => _tabIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.radar), label: 'Tarama'),
          NavigationDestination(icon: Icon(Icons.history), label: 'Geçmiş'),
          NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Performans'),
        ],
      ),
    );
  }
}

class ReplayPage extends StatelessWidget {
  const ReplayPage({
    super.key,
    required this.clock,
    required this.minuteIndex,
    required this.speed,
    required this.isPlaying,
    required this.results,
    required this.onPlay,
    required this.onSpeedChanged,
    required this.onSliderChanged,
  });

  final String clock;
  final int minuteIndex;
  final double speed;
  final bool isPlaying;
  final List<SignalResult> results;
  final VoidCallback onPlay;
  final ValueChanged<double> onSpeedChanged;
  final ValueChanged<double> onSliderChanged;

  @override
  Widget build(BuildContext context) {
    final selected = results.where((e) => e.signal != SignalType.reject).take(3).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ReplayControls(
          clock: clock,
          minuteIndex: minuteIndex,
          speed: speed,
          isPlaying: isPlaying,
          onPlay: onPlay,
          onSpeedChanged: onSpeedChanged,
          onSliderChanged: onSliderChanged,
        ),
        const SizedBox(height: 18),
        Text('En güçlü adaylar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        if (selected.isEmpty)
          const InfoCard(text: 'Bu dakikada eşik üstünde güçlü aday bulunamadı.')
        else
          ...selected.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: CandidateCard(result: item),
              )),
        const SizedBox(height: 10),
        Text('Tüm tarama sonuçları', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        ...results.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: CompactSignalTile(result: item),
            )),
        const SizedBox(height: 12),
        const InfoCard(
          text: 'Bu uygulama otomatik emir göndermez. Bu sürüm yalnızca örnek geçmiş veriyle test amaçlı çalışır.',
        ),
      ],
    );
  }
}

class ReplayControls extends StatelessWidget {
  const ReplayControls({
    super.key,
    required this.clock,
    required this.minuteIndex,
    required this.speed,
    required this.isPlaying,
    required this.onPlay,
    required this.onSpeedChanged,
    required this.onSliderChanged,
  });

  final String clock;
  final int minuteIndex;
  final double speed;
  final bool isPlaying;
  final VoidCallback onPlay;
  final ValueChanged<double> onSpeedChanged;
  final ValueChanged<double> onSliderChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                IconButton.filled(
                  onPressed: onPlay,
                  icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(clock, style: Theme.of(context).textTheme.headlineSmall),
                      Text('Dakika ${minuteIndex + 1}/${MockMarketRepository.totalMinutes}'),
                    ],
                  ),
                ),
                DropdownButton<double>(
                  value: speed,
                  items: const [
                    DropdownMenuItem(value: 1, child: Text('1x')),
                    DropdownMenuItem(value: 2, child: Text('2x')),
                    DropdownMenuItem(value: 5, child: Text('5x')),
                  ],
                  onChanged: (value) {
                    if (value != null) onSpeedChanged(value);
                  },
                ),
              ],
            ),
            Slider(
              value: minuteIndex.toDouble(),
              max: (MockMarketRepository.totalMinutes - 1).toDouble(),
              divisions: MockMarketRepository.totalMinutes - 1,
              onChanged: onSliderChanged,
            ),
          ],
        ),
      ),
    );
  }
}

class CandidateCard extends StatelessWidget {
  const CandidateCard({super.key, required this.result});
  final SignalResult result;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(result.symbol, style: Theme.of(context).textTheme.headlineSmall),
                ),
                SignalBadge(signal: result.signal),
              ],
            ),
            Text('${result.price.toStringAsFixed(2)} TL  •  Skor ${result.finalScore}/100'),
            const SizedBox(height: 12),
            LinearProgressIndicator(value: result.finalScore / 100),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                MetricChip(label: 'Hacim', value: '${result.volumeScore}'),
                MetricChip(label: 'Momentum', value: '${result.momentumScore}'),
                MetricChip(label: 'Erken hareket', value: '${result.earlyMoveScore}'),
                MetricChip(label: 'Risk', value: '${result.riskScore}'),
                MetricChip(label: 'R/Ö', value: result.riskReward.toStringAsFixed(2)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CompactSignalTile extends StatelessWidget {
  const CompactSignalTile({super.key, required this.result});
  final SignalResult result;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(result.symbol),
        subtitle: Text('${result.price.toStringAsFixed(2)} TL • R/Ö ${result.riskReward.toStringAsFixed(2)}'),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('${result.finalScore}', style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(result.signal.label, style: TextStyle(color: result.signal.color)),
          ],
        ),
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key, required this.history});
  final List<SignalEvent> history;

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) {
      return const Center(child: Text('Henüz sinyal oluşmadı.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: history.length,
      itemBuilder: (context, index) {
        final event = history[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Card(
            child: ListTile(
              title: Row(
                children: [
                  Expanded(child: Text(event.symbol)),
                  SignalBadge(signal: event.signal),
                ],
              ),
              subtitle: Text(
                '${event.time} • Giriş ${event.entryPrice.toStringAsFixed(2)} TL\n'
                'Skor ${event.score} • En yüksek ${event.maxGainPercent.toStringAsFixed(2)}% • '
                'En düşük ${event.maxDrawdownPercent.toStringAsFixed(2)}%',
              ),
              trailing: Text(
                '${event.currentChangePercent >= 0 ? '+' : ''}${event.currentChangePercent.toStringAsFixed(2)}%',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: event.currentChangePercent >= 0 ? Colors.greenAccent : Colors.redAccent,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class PerformancePage extends StatelessWidget {
  const PerformancePage({super.key, required this.history});
  final List<SignalEvent> history;

  @override
  Widget build(BuildContext context) {
    final total = history.length;
    final winners = history.where((event) => event.currentChangePercent >= 1).length;
    final avg = total == 0
        ? 0.0
        : history.map((e) => e.currentChangePercent).reduce((a, b) => a + b) / total;
    final best = total == 0
        ? 0.0
        : history.map((e) => e.maxGainPercent).reduce(max);
    final worst = total == 0
        ? 0.0
        : history.map((e) => e.maxDrawdownPercent).reduce(min);
    final successRate = total == 0 ? 0.0 : (winners / total) * 100;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Test performansı', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.35,
          children: [
            StatCard(title: 'Toplam sinyal', value: '$total'),
            StatCard(title: 'Başarı oranı', value: '${successRate.toStringAsFixed(1)}%'),
            StatCard(title: 'Ortalama sonuç', value: '${avg.toStringAsFixed(2)}%'),
            StatCard(title: 'En iyi hareket', value: '${best.toStringAsFixed(2)}%'),
            StatCard(title: 'En kötü geri çekilme', value: '${worst.toStringAsFixed(2)}%'),
            StatCard(title: 'Başarılı sinyal', value: '$winners'),
          ],
        ),
        const SizedBox(height: 16),
        const InfoCard(
          text: 'Başarı tanımı bu testte sinyal sonrasında en az +%1 mevcut sonuçtur. Gerçek sürümde 15, 30 ve 60 dakikalık ayrı ölçümler kullanılacaktır.',
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(value, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            Text(title, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class SignalBadge extends StatelessWidget {
  const SignalBadge({super.key, required this.signal});
  final SignalType signal;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: signal.color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(signal.label, style: TextStyle(color: signal.color, fontWeight: FontWeight.bold)),
    );
  }
}

class MetricChip extends StatelessWidget {
  const MetricChip({super.key, required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Chip(label: Text('$label: $value'));
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.info_outline),
            const SizedBox(width: 10),
            Expanded(child: Text(text)),
          ],
        ),
      ),
    );
  }
}

class ScoringEngine {
  static SignalResult score(MarketPoint point) {
    final volumeScore = ((point.relativeVolume - 0.8) * 30).clamp(0, 30).round();
    final momentumScore = ((point.momentumPercent + 0.2) * 15).clamp(0, 25).round();
    final earlyMoveScore = ((point.buyPressure - 45) * 0.7 + (point.breakoutPressure * 12))
        .clamp(0, 25)
        .round();
    final riskScore = ((2.2 - point.volatilityPercent) * 10).clamp(0, 20).round();
    final finalScore = (volumeScore + momentumScore + earlyMoveScore + riskScore).clamp(0, 100);
    final riskReward = ((point.momentumPercent.abs() + point.breakoutPressure + 0.5) /
            max(point.volatilityPercent, 0.35))
        .clamp(0.5, 4.5)
        .toDouble();

    SignalType signal = SignalType.reject;
    if (finalScore >= 88 && riskReward >= 1.8) {
      signal = SignalType.strong;
    } else if (finalScore >= 80 && riskReward >= 1.35) {
      signal = SignalType.watch;
    }

    return SignalResult(
      symbol: point.symbol,
      price: point.price,
      finalScore: finalScore,
      volumeScore: volumeScore,
      momentumScore: momentumScore,
      earlyMoveScore: earlyMoveScore,
      riskScore: riskScore,
      riskReward: riskReward,
      signal: signal,
    );
  }
}

class MockMarketRepository {
  static const int totalMinutes = 90;
  static const List<String> symbols = ['ASELS', 'THYAO', 'KCHOL', 'EREGL', 'TUPRS', 'SASA', 'FROTO'];
  final Map<String, List<MarketPoint>> _series = <String, List<MarketPoint>>{};

  MockMarketRepository() {
    for (var i = 0; i < symbols.length; i++) {
      _series[symbols[i]] = _generate(symbols[i], i);
    }
  }

  List<MarketPoint> snapshotAt(int minuteIndex) {
    final safeIndex = minuteIndex.clamp(0, totalMinutes - 1);
    return symbols.map((symbol) => _series[symbol]![safeIndex]).toList();
  }

  MarketPoint? pointFor(String symbol, int minuteIndex) {
    final list = _series[symbol];
    if (list == null) return null;
    return list[minuteIndex.clamp(0, totalMinutes - 1)];
  }

  List<MarketPoint> _generate(String symbol, int seedOffset) {
    final random = Random(6500 + seedOffset * 37);
    final basePrice = 20 + seedOffset * 17.5;
    double price = basePrice;
    final points = <MarketPoint>[];

    for (var minute = 0; minute < totalMinutes; minute++) {
      final wave = sin((minute + seedOffset * 4) / 8) * 0.10;
      final eventBoost = _eventBoost(seedOffset, minute);
      final noise = (random.nextDouble() - 0.5) * 0.12;
      final momentum = wave + eventBoost + noise;
      price *= 1 + momentum / 100;

      points.add(MarketPoint(
        symbol: symbol,
        price: price,
        relativeVolume: 0.85 + random.nextDouble() * 0.8 + eventBoost.abs() * 2.4,
        momentumPercent: momentum * 2.6,
        buyPressure: 47 + random.nextDouble() * 13 + eventBoost * 30,
        breakoutPressure: max(0, eventBoost * 4 + random.nextDouble() * 0.35),
        volatilityPercent: 0.7 + random.nextDouble() * 1.1,
      ));
    }
    return points;
  }

  double _eventBoost(int seedOffset, int minute) {
    final start = 12 + seedOffset * 7;
    if (minute >= start && minute <= start + 11 && seedOffset % 2 == 0) {
      return 0.33 + (minute - start) * 0.015;
    }
    if (minute >= 48 && minute <= 58 && seedOffset == 1) {
      return 0.40;
    }
    return 0;
  }
}

class MarketPoint {
  const MarketPoint({
    required this.symbol,
    required this.price,
    required this.relativeVolume,
    required this.momentumPercent,
    required this.buyPressure,
    required this.breakoutPressure,
    required this.volatilityPercent,
  });

  final String symbol;
  final double price;
  final double relativeVolume;
  final double momentumPercent;
  final double buyPressure;
  final double breakoutPressure;
  final double volatilityPercent;
}

class SignalResult {
  const SignalResult({
    required this.symbol,
    required this.price,
    required this.finalScore,
    required this.volumeScore,
    required this.momentumScore,
    required this.earlyMoveScore,
    required this.riskScore,
    required this.riskReward,
    required this.signal,
  });

  final String symbol;
  final double price;
  final int finalScore;
  final int volumeScore;
  final int momentumScore;
  final int earlyMoveScore;
  final int riskScore;
  final double riskReward;
  final SignalType signal;
}

class SignalEvent {
  SignalEvent({
    required this.symbol,
    required this.minuteIndex,
    required this.time,
    required this.entryPrice,
    required this.score,
    required this.riskReward,
    required this.signal,
  });

  final String symbol;
  final int minuteIndex;
  final String time;
  final double entryPrice;
  final int score;
  final double riskReward;
  final SignalType signal;
  double currentChangePercent = 0;
  double maxGainPercent = 0;
  double maxDrawdownPercent = 0;
}

enum SignalType {
  strong,
  watch,
  reject;

  String get label {
    switch (this) {
      case SignalType.strong:
        return 'Güçlü';
      case SignalType.watch:
        return 'İzle';
      case SignalType.reject:
        return 'Ele';
    }
  }

  Color get color {
    switch (this) {
      case SignalType.strong:
        return Colors.greenAccent;
      case SignalType.watch:
        return Colors.amberAccent;
      case SignalType.reject:
        return Colors.redAccent;
    }
  }
}
